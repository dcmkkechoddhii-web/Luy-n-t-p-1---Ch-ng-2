#include <stdio.h>

int main() {
    // V� d? h?p l?
    int age = 20;
    float diem_trung_binh = 8.5;
    char kyTu = 'A';

    printf("Xem comment de biet chi tiet.\n");

    return 0;
}
