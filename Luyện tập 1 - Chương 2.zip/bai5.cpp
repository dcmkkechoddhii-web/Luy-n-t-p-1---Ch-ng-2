#include <stdio.h>

int main() {
    const int soNguyen = 100;
    const float soThuc = 3.14;
    const char chuoi[] = "Lap trinh C";

    printf("So nguyen: %d\n", soNguyen);
    printf("So thuc: %.2f\n", soThuc);
    printf("Chuoi: %s\n", chuoi);

    return 0;
}
